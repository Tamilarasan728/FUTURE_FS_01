const Cart = ({ cartItems }) => {
  const total = cartItems.reduce((sum, item) => sum + item.price, 0);
  return (
    <div className="fixed bottom-4 right-4 bg-white shadow-lg p-4 rounded-xl w-64">
      <h3 className="text-lg font-bold mb-2">Cart Summary</h3>
      {cartItems.length === 0 ? (
        <p className="text-gray-500">No items in cart</p>
      ) : (
        <ul className="mb-2">
          {cartItems.map((item, idx) => (
            <li key={idx} className="text-sm text-gray-700">
              {item.name} - ₹{item.price}
            </li>
          ))}
        </ul>
      )}
      <p className="font-semibold">Total: ₹{total}</p>
    </div>
  );
};
export default Cart;