const ProductModal = ({ product, onClose }) => (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
    <div className="bg-white p-6 rounded-lg w-11/12 md:w-1/2 relative">
      <button
        onClick={onClose}
        className="absolute top-2 right-2 text-red-500 text-xl"
      >
        ✖
      </button>
      <img src={product.image} alt={product.name} className="mb-4 rounded" />
      <h2 className="text-2xl font-bold">{product.name}</h2>
      <p className="text-gray-700 mb-2">{product.description}</p>
      <p className="text-lg font-semibold">₹{product.price}</p>
    </div>
  </div>
);
export default ProductModal;