const ProductCard = ({ product, onAdd, onView }) => (
  <div className="bg-white rounded-xl shadow-md p-4">
    <img src={product.image} alt={product.name} className="rounded mb-2" />
    <h2 className="text-xl font-bold">{product.name}</h2>
    <p className="text-sm text-gray-600">₹{product.price}</p>
    <div className="mt-2 flex gap-2">
      <button
        onClick={onAdd}
        className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600"
      >
        Add to Cart
      </button>
      <button
        onClick={onView}
        className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
      >
        View
      </button>
    </div>
  </div>
);
export default ProductCard;