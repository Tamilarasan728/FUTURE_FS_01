const Navbar = ({ cartCount }) => (
  <div className="bg-white shadow p-4 flex justify-between items-center">
    <h1 className="text-2xl font-bold text-blue-600">Mini Store</h1>
    <div className="text-gray-700">
      🛒 Cart: <span className="font-semibold">{cartCount}</span>
    </div>
  </div>
);
export default Navbar;