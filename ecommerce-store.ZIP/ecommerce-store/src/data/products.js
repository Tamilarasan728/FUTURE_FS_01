const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 2999,
    image: "https://via.placeholder.com/200",
    description: "High quality wireless headphones with noise cancellation.",
  },
  {
    id: 2,
    name: "Smart Watch",
    price: 4999,
    image: "https://via.placeholder.com/200",
    description: "Stay connected and track your fitness.",
  },
  {
    id: 3,
    name: "Bluetooth Speaker",
    price: 1999,
    image: "https://via.placeholder.com/200",
    description: "Portable and powerful sound.",
  },
];
export default products;