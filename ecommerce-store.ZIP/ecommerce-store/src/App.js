import React, { useState } from "react";
import products from "./data/products";
import Navbar from "./components/Navbar";
import ProductCard from "./components/ProductCard";
import ProductModal from "./components/ProductModal";
import Cart from "./components/Cart";

function App() {
  const [cart, setCart] = useState([]);
  const [selected, setSelected] = useState(null);

  const addToCart = (product) => {
    setCart((prev) => [...prev, product]);
  };

  return (
    <div className="bg-gray-50 min-h-screen">
      <Navbar cartCount={cart.length} />
      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onAdd={() => addToCart(product)}
            onView={() => setSelected(product)}
          />
        ))}
      </div>
      {selected && <ProductModal product={selected} onClose={() => setSelected(null)} />}
      <Cart cartItems={cart} />
    </div>
  );
}
export default App;